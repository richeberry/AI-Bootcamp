"""
Bare Minimum Requirements

요구사항
    큐, 스택을 구현해주세요.
    각 메소드에 작성되어있는 문제를 확인하여 코드를 작성해주세요.

    단 collections 라이브러리는 사용하지 마세요.
    메소드 이름은 변경하지 마세요.
    메소드의 매개변수를 추가하거나 삭제하지 마세요.
"""

class Queue():
    def __init__(self):
        self.queue = []


    def enqueue(self,item):
        self.queue.append(item)


    def dequeue(self):
        if len(self.queue) == 0:
            return None
        return self.queue.pop(0)



    def return_queue(self):
        return list(self.queue)


class Stack():
    def __init__(self):
        self.stack = []


    def push(self, item):
        self.stack.append(item)


    def pop(self):
        if len(self.stack) == 0:
            return None
        return self.stack.pop()
            
        


    def return_stack(self):
        return list(self.stack)

    
