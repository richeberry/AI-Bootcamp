"""
Bare Minimum Requirements
연결리스트의 개념은 변수의 인덱스에 직접접근하는 배열개념과는 다릅니다.
참조의 개념을 활용하여 변수에 접근하는 방법을 익혀봅니다.

요구사항:
    주어진 문제는 연결리스트지만 독립적으로 개념이 운용되는 것은 아닙니다.

    연결리스트를 구현해주세요.
    각 메소드에 작성되어있는 문제를 확인하여 코드를 작성해주세요.

    단 collections 라이브러리는 사용하지 마세요.
    메소드 이름은 변경하지 마세요.
    메소드의 매개변수를 추가하거나 삭제하지 마세요.
"""

class Node:
    def __init__(self,value,next=None): # next 다음 노드가 없으므로 None
        self.value = value
        self.next = next


class linked_list:
    def __init__(self, value):
        self.head = Node(value) # 헤드 (첫번째 링크) 노드 만듦


    def add_node(self, value):
        if self.head == None:
                self.head = Node(value)
        else:
            node = self.head
            while node.next:
                node = node.next
            node.next = Node(value) # init함수의 value


    def del_node(self,value):
        if self.head == None:
            pass
        # 해당 값에 대한 노드는 없다.
        # 의미없는 조건에서 함수는 아무것도 반환하지 않는다. 
        elif self.head.value == value:
            tmp = self.head
            self.head = self.head.next
            del tmp
            return value
        # 노드의 위치를 변경시킨다.
        # 변경된 노드에 대해서 삭제를 진행한다.
        else:
            node = self.head
        while node.next:
            if node.next.value == value:
                node.next = node.next.next # 그 다음 노드
                return value
            # 노드의 위치를 변경시킨다.
            # 변경된 노드에 대해서 삭제를 진행한다.
            else : 
                node = node.next
            # 다음 노드의 위치를 현재 노드에 넣어준다.


    def ord_desc(self):
        node = self.head
        tmp = []
        while node:
            tmp.append(node.value)
            node = node.next 
        return tmp


    def search_node(self,value):
        node = self.head
        while node:
            if node.value == value:
                return node 
            node = node.next

