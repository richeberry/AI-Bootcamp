"""
Advanced Requirements
새로운 자료구조를 찾아보고 공부해보세요.

요구사항:
    Deque가 무엇인지 구글링을 통해 공부해주세요.
    아래는 위키백과에 있는 Deque의 설명입니다. 
    https://ko.wikipedia.org/wiki/%EB%8D%B1_(%EC%9E%90%EB%A3%8C_%EA%B5%AC%EC%A1%B0)

    Deque에 대해서 공부가 끝났다면 이제 구현해볼 차례입니다. 
    오늘 공부한 LinkedList를 사용하여 Deque를 구현해주세요.
    collection 라이브러리는 사용하지 마세요.
"""

class Node:
    """
    Deque 클래스에서 사용할 Node 클래스입니다.
    작성된 코드를 수정하거나 삭제하지 마세요.
    """
    def __init__(self, value, next=None):
        self.value = value
        self.next = next


class Deque:
    def __init__(self):
        """
        아래 코드는 수정하지 마세요.
        작성된 코드의 의도를 생각해보며 문제를 풀어주세요.
        """
        self.top = None
        self.bottom = None


    def append(self, item):
        new_node = Node(item)
        if self.top is None:
            self.top = new_node
            self.bottom = new_node
        else:
            self.bottom.next = new_node
            self.bottom = new_node
        """
        #. 문제 1.
        Deque에 item 매개변수로 들어온 값을 제일 마지막 노드로 집어넣는 메소드를 구현해주세요.

        input: item
            Deque로 들어갈 값입니다.
        output: 
            반환값은 없습니다.
        아래 pass를 지워주시고 코드를 작성해주시면 됩니다. 
        """


    def appendleft(self, item):
        new_node = Node(item)
        
        if self.top is None: # 노드가 비어있으면 
            self.top = new_node # top = bottom 노드 하나 추가
            self.bottom = new_node 
        else:
            new_node.next = self.top
            self.top = new_node
        """
        #. 문제 2.
        Deque에 item 매개변수로 들어온 값을 제일 앞 노드로 집어넣는 메소드를 구현해주세요.

        input: item
            Deque로 들어갈 값입니다.
        output: 
            반환값은 없습니다.
        아래 pass를 지워주시고 코드를 작성해주시면 됩니다. 
        """



    def pop(self): 
        if self.top is None: # Deque에 노드가 없다면
            return None
        
        elif self.top == self.bottom: # Deque 1개 노드이면
            del_node = self.bottom # 아래 노드로 설정(하고 지우기)
            self.top = None # 원래 없는 노드 
            self.bottom = None # pop한 노드
        
            return del_node.value
    
        else: # Deque에 노드가 있다면
            explode_node = self.top # 첫번째 노드부터 탐색
            while explode_node.next is not self.bottom:
                explode_node = explode_node.next

            del_node = self.bottom      # 맨 아래 노드 삭제
            self.bottom = explode_node  # 맨 아래 노드 삭제하고 탐색한 노드가 맨 아래로 됨

            return del_node.value
        """
        #. 문제 3.
        Deque에 가장 뒤에 있는 값을 삭제하는 메소드를 구현해주세요.

        input: 
            input은 없습니다.
        output: 
            Deque에서 삭제된 값을 반환해주세요.
            만약 삭제한 값이 없다면 None을 반환해주세요.
        아래 pass를 지워주시고 코드를 작성해주시면 됩니다. 
        """



    def popleft(self):
        
        if self.top is None: # Deque가 비어있으면 None 반환
            return None
        elif self.top == self.bottom: # 1개의 노드가 있으면
            del_node = self.top # 위 노드 삭제
            self.top = None
            self.bottom = None
            return del_node.value
        
        else: # 노드가 2개 이상이먀면
            del_node = self.top # 맨 위 노드 삭제
            self.top = self.top.next # top 노드의 다음 노드가 top이 됨
            
            return del_node.value
        """
        #. 문제 4.
        Deque에 가장 앞에 있는 값을 삭제하는 메소드를 구현해주세요.

        input: 
            input은 없습니다.
        output: 
            Deque에서 삭제된 값을 반환해주세요.
            만약 삭제한 값이 없다면 None을 반환해주세요.
        아래 pass를 지워주시고 코드를 작성해주시면 됩니다. 
        """



    def ord_desc(self):
        """
        #. 문제 5.
        queue내부에 있는 값을 반환하는 메소드를 구현해주세요.

        input: 
            input은 없습니다.
        output: 
            queue내부에 있는 값을 리스트 형태로 반환해주세요.
        아래 pass를 지워주시고 코드를 작성해주시면 됩니다. 
        """
        node = self.top # 맨 위 노드 
        value_list = list()
        while node: # 노드가 있다면
            value_list.append(node.value) # values 리스트에 node.value 추가 
            node = node.next # 다음 노드로 가서 while문
        return value_list
